package com.example;

public class Constants {
    public static int TOTAL_SEATS = 210;
    public static int ECONOMY_SEATS = 120;
    public static int BUSINESS_SEATS = 60;
    public static int FIRST_SEATS = 30;
}
