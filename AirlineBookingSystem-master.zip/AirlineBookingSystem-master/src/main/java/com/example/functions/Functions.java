package com.example.functions;

public class Functions implements  GetPass, BookTicket,CheckFlights,GetHistory{

}
